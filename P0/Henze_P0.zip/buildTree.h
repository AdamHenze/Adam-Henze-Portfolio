// Adam Henze
// cs4280
// Sharlee Climer
// P0
// 2/10/2024

#ifndef BUILDTREE_H
#define BUILDTREE_H

#include <cstdio>
#include "node.h"

// only build tree used beyond buildtree.c
node_t* buildTree(FILE*);

#endif
